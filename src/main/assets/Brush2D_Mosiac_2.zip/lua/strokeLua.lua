local exports = exports or {}
local strokeLua = strokeLua or {}
strokeLua.__index = strokeLua

function strokeLua.new(construct, ...)
    local self = setmetatable({}, strokeLua)
    if construct and strokeLua.constructor then
        strokeLua.constructor(self, ...)
    end
    return self
end
function strokeLua:constructor()
end

function strokeLua:onStrokeStart(comp, stroke, canvas)
    self.stroke = stroke
    self.resolution = canvas.resolution
    self.blitMaterial = canvas.blitMaterial
    self.renderMaterial = canvas.brushMaterial
    self.strokeMesh = stroke.mesh
    self.generator = stroke.meshGenerator
    self.undoTexCache = stroke.undoTexCache
    self.redoTexCache = stroke.redoTexCache
    self.renderMaterial:setVec2("resolution", self.resolution)
    self.renderMaterial:setFloat("strokeSize", self.generator:getStrokeSize())
    self.renderMaterial:setTex("originTexture", comp.scene:getInputTexture(Amaz.BuiltInTextureType.INPUT0))

    self.cacheFlag = false
    self.targetCache = Amaz.RenderTexture()
    self.targetCache.width = self.resolution.x
    self.targetCache.height = self.resolution.y
    self.outputTex = Amaz.RenderTexture()
    self.outputTex.width = self.resolution.x
    self.outputTex.height = self.resolution.y
    self.renderCmd = Amaz.CommandBuffer()
    self.cacheCmd = Amaz.CommandBuffer()
    self.stModel = Amaz.Matrix4x4f()
    self.stModel:SetIdentity()
    self.screenMesh = Amaz.Mesh()
    Amaz.Brush2DUtils.generateBBoxMesh(Amaz.AABB(), self.screenMesh, false, false)
    self.bboxMesh = Amaz.Mesh()
    self.cropMesh = Amaz.Mesh()
end
function strokeLua:onStrokeUpdate(comp, deltaTime)
    self.renderCmd:clearAll()
    self.cacheCmd:clearAll()
    self.blitMaterial:setTex("inputTexture", nil)
end
function strokeLua:onStrokeRender(comp, target)
    local dirty = self.stroke.dirtyFlag
    local finished = self.stroke:isFinished()
    if dirty == Amaz.Brush2DDirtyFlag.Unchanged and self.cacheFlag then
        return
    end

    if dirty == Amaz.Brush2DDirtyFlag.Increase then
        self.strokeBBox = self.stroke.boundingBox
        Amaz.Brush2DUtils.generateBBoxMesh(self.strokeBBox, self.bboxMesh, true, true)
        local subMeshIndex = self.strokeMesh.submeshes:size() - 1
        if subMeshIndex == 0 then
            self.renderCmd:setRenderTexture(self.outputTex)
            self.renderCmd:clearRenderTexture(true, false, Amaz.Color(0, 0, 0, 0))
            self.renderCmd:setRenderTexture(self.targetCache)
            self.renderCmd:setGlobalTexture("inputTexture", target)
            self.renderCmd:drawMesh(self.screenMesh, self.stModel, self.blitMaterial, 0, 0, nil)
        end
        self.renderCmd:setRenderTexture(self.outputTex)
        self.renderCmd:drawMesh(self.strokeMesh, self.stModel, self.renderMaterial, subMeshIndex, 0, nil)
        self.renderCmd:setGlobalTexture("layerTexture", self.targetCache)
        self.renderCmd:setGlobalTexture("strokeTexture", self.outputTex)
        self.renderCmd:setRenderTexture(target)
        self.renderCmd:drawMesh(self.bboxMesh, self.stModel, self.renderMaterial, 0, 1, nil)
        comp.entity.scene:commitCommandBuffer(self.renderCmd)
    elseif dirty == Amaz.Brush2DDirtyFlag.Undo then
        if self.undoTexCache then
            self.cacheTex = self.undoTexCache:getTexture()
        end
    elseif dirty == Amaz.Brush2DDirtyFlag.Redo then
        if self.redoTexCache then
            self.cacheTex = self.redoTexCache:getTexture()
        end
    elseif dirty == Amaz.Brush2DDirtyFlag.Cache then
        self.cacheTex = nil
        collectgarbage("collect")
    end
    dirty = Amaz.Brush2DDirtyFlag.Unchanged

    if finished then
        if not self.cacheFlag then
            local cacheResolution = self.generator.resolution
            Amaz.Brush2DUtils.alignBBoxToResolution(cacheResolution, self.strokeBBox)
            Amaz.Brush2DUtils.generateBBoxMesh(self.strokeBBox, self.cropMesh, false, true)
            local cacheWidth = (self.strokeBBox.max_x - self.strokeBBox.min_x) * cacheResolution.x
            local cacheHeight = (self.strokeBBox.max_y - self.strokeBBox.min_y) * cacheResolution.y
            if self.undoTexCache then
                self.undoTex = Amaz.RenderTexture()
                self.undoTex.width = cacheWidth
                self.undoTex.height = cacheHeight
                self.undoTexCache:setTexture(self.undoTex)
                self.cacheCmd:setRenderTexture(self.undoTex)
                self.cacheCmd:setGlobalTexture("inputTexture", self.targetCache)
                self.cacheCmd:drawMesh(self.cropMesh, self.stModel, self.blitMaterial, 0, 0, nil)
            end
            if self.redoTexCache then
                self.redoTex = Amaz.RenderTexture()
                self.redoTex.width = cacheWidth
                self.redoTex.height = cacheHeight
                self.redoTexCache:setTexture(self.redoTex)
                self.cacheCmd:setRenderTexture(self.redoTex)
                self.cacheCmd:setGlobalTexture("inputTexture", target)
                self.cacheCmd:drawMesh(self.cropMesh, self.stModel, self.blitMaterial, 0, 0, nil)
            end
            comp.entity.scene:commitCommandBuffer(self.cacheCmd)
            dirty = Amaz.Brush2DDirtyFlag.Cache
            self.cacheFlag = true
        elseif self.cacheTex then
            self.blitMaterial:setTex("inputTexture", self.cacheTex)
            self.renderCmd:setRenderTexture(target)
            self.renderCmd:drawMesh(self.cacheMesh, self.stModel, self.blitMaterial, 0, 0, nil)
            comp.entity.scene:commitCommandBuffer(self.renderCmd)
            dirty = Amaz.Brush2DDirtyFlag.Cache
        end
    end

    self.stroke.dirtyFlag = dirty
end
function strokeLua:onStrokeFinish()
    self.resolution = nil
    self.strokeMesh = nil
    self.generator = nil

    self.targetCache = nil
    self.outputTex = nil
    self.undoTex = nil
    self.redoTex = nil
    self.screenMesh = nil
    self.bboxMesh = nil
    self.cropMesh = nil
    self.cacheMesh = Amaz.Mesh()
    Amaz.Brush2DUtils.generateBBoxMesh(self.strokeBBox, self.cacheMesh, true, false)

    collectgarbage("collect")
end

exports.strokeLua = strokeLua
return exports