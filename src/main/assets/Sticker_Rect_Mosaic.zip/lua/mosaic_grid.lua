local exports = exports or {}
local mosaic_grid = mosaic_grid or {}
mosaic_grid.__index = mosaic_grid

function mosaic_grid.new(construct, ...)
    local self = setmetatable({}, mosaic_grid)
    if construct and mosaic_grid.constructor then mosaic_grid.constructor(self, ...) end
    return self
end

function mosaic_grid:constructor()

end

function mosaic_grid:onStart(comp)
    self.mosaic = comp.entity:searchEntity("mosaic")
    self.mosaicTrans = self.mosaic:getComponent("Transform")
    self.mosaicRenderer = self.mosaic:getComponent("Sprite2DRenderer")
    self.material = self.mosaicRenderer.material
end

function mosaic_grid:onUpdate(comp, deltaTime)
    local outputW = Amaz.BuiltinObject:getOutputTextureWidth()
    local outputH = Amaz.BuiltinObject:getOutputTextureHeight()
    self.material:setVec2("resolution", Amaz.Vector2f(outputW, outputH))
end

exports.mosaic_grid = mosaic_grid
return exports
