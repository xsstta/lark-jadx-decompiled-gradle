
local initOnce = true
local initFlag = false

EventHandles = {
    handleEffectEvent = function(this, eventCode)
        if initOnce and eventCode == 1 then
            initFlag = true
        end
        return true
    end,

    handleUpdate = function(this, timestamp)
        if initFlag == false then
            return false
        end
        local effectManager = this:getEffectManager()
        if effectManager then
            local orientation = effectManager:getRenderCacheIntValue("BCCustomBackground_orientation")
            local feature = this:getFeature("GE/")
            feature = EffectSdk.castGeneralEffectFeature(feature)
            if feature then
                feature:setUniformFloat("matting", 1, "bgTextureRotate", orientation)
            end
            feature:setFeatureStatus(0x04, true);
        end
    end,
}