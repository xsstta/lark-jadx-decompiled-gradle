
EventHandles =
{
    handleComposerUpdateNodeEvent = function(this, path, tag, value)
        if (tag == "blur_mean") then
            local feature = this:getFeature("ge_matting_smooth")
            local featureES = EffectSdk.castGeneralEffectFeature(feature)
            if (featureES) then
                featureES:setUniformFloat("blur1_mean", 1, "radius", value)
                featureES:setUniformFloat("blur2_mean", 1, "radius", value)
            end
        end
    end
}
