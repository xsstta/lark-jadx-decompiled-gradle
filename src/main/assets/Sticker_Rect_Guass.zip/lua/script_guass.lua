local exports = exports or {}
local script_guass = script_guass or {}
script_guass.__index = script_guass

function script_guass.new(construct, ...)
    local self = setmetatable({}, script_guass)
    if construct and script_guass.constructor then script_guass.constructor(self, ...) end
    return self
end

function script_guass:constructor()
end

function script_guass:onStart(comp)
    self.guassEntity = comp.entity
    self.guassMesh = comp.properties:get("guass_mesh")
    self.guassMaterial = comp.properties:get("guass_material")
    self.mosaicEntity = comp.entity:searchEntity("mosaic_guass")
    self.mosaicRenderer = self.mosaicEntity:getComponent("Sprite2DRenderer")
    self.mosaicMaterial = self.mosaicRenderer.material
    self.blurGuid = Amaz.Guid("25609", "17247")
    self.blurRt = Amaz.AmazingUtil.guidToPointer(self.blurGuid)
end

function script_guass:onUpdate(comp, deltaTime)
    if self.blurRt == nil then
        if self.blurRtTmp == nil then
            self.blurRtTmp = Amaz.RenderTexture()
            self.blurRtTmp.guid = self.blurGuid
            self.blurRtTmp.width = Amaz.BuiltinObject:getOutputTextureWidth()
            self.blurRtTmp.height = Amaz.BuiltinObject:getOutputTextureHeight()
            self.commandBuffer = Amaz.CommandBuffer()
            local model = Amaz.Matrix4x4f():SetIdentity()
            self.commandBuffer:setRenderTexture(self.blurRtTmp)
            self.commandBuffer:drawMesh(self.guassMesh, model, self.guassMaterial, 0, 0, nil)
        end
        self.guassEntity.scene:commitCommandBuffer(self.commandBuffer)
        self.mosaicMaterial:setTex("_OriginTex", self.blurRtTmp)
    else
        self.mosaicMaterial:setTex("_OriginTex", self.blurRt)
    end
end

exports.script_guass = script_guass
return exports

